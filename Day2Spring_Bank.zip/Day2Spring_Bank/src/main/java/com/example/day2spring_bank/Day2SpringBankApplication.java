package com.example.day2spring_bank;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class Day2SpringBankApplication {

    public static void main(String[] args) {
        SpringApplication.run(Day2SpringBankApplication.class, args);
    }

}
