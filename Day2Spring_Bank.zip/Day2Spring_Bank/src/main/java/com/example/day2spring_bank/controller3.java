package com.example.day2spring_bank;

import org.springframework.web.bind.annotation.*;

import java.util.ArrayList;

@RestController
@RequestMapping("/api/v1")
public class controller3 {

    ArrayList<Customer> customer = new ArrayList<>();

    @GetMapping("/customer")
    public ArrayList<Customer> getCustomer(){
        return customer;
    }

    @PostMapping("/add")
    public ApiResponse addCustomer(@RequestBody Customer cust){
        customer.add(cust);
        return new ApiResponse("Customer added!");
    }
@PutMapping("/update/{index}")
    public ApiResponse updateCustomer(@PathVariable int index, @RequestBody Customer cust) {
        customer.set(index,cust);
        return new ApiResponse("Customer updated!");
    }
@DeleteMapping("/{index}")
    public ApiResponse deleteCustomer(@PathVariable int index){
        customer.remove(index);
        return new ApiResponse("Customer deleted!");
    }

    @PutMapping("/deposit/{index}")
    public ApiResponse deposit(@PathVariable int index, @RequestBody Customer cust){
        customer.set(index,cust);
        return new ApiResponse("deposit added!");
    }

    @PutMapping("/withdraw/{index}")
    public ApiResponse withdraw(@PathVariable int index, @RequestBody Customer cust){


        double T = cust.getBalance();
        double B =customer.get(index).getBalance();
        if (T > B){
            return new ApiResponse("withdraw failed");
        }
        else {

            cust.setBalance(customer.get(index).getBalance() - cust.getBalance());
            customer.set(index,cust);
            return new ApiResponse("withdraw sucssed");
        }
    }
}
