package com.example.day2spring_bank;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class Day2SpringBankApplicationTests {

    @Test
    void contextLoads() {
    }

}
