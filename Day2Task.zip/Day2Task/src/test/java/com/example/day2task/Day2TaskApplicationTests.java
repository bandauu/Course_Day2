package com.example.day2task;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class Day2TaskApplicationTests {

    @Test
    void contextLoads() {
    }

}
