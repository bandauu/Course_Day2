package com.example.day2task;

import org.springframework.web.bind.annotation.*;

import java.util.ArrayList;

@RestController
@RequestMapping("/api/v1")
public class Controller4 {

    ArrayList<Task> tasks = new ArrayList<>();
    @GetMapping("/task")
    public ArrayList<Task> getTask(){
        return tasks;
    }

    @PostMapping("/add")
    public ApiResponse addTask(@RequestBody Task tas){
        tasks.add(tas);
        return new ApiResponse("task added!");
    }

    @PutMapping("/{index}")
    public ApiResponse updateTask(@PathVariable int index ,@RequestBody Task tas) {
        tasks.set(index, tas);
        return new ApiResponse("task updated!");
    }

    @DeleteMapping("/{index}")
    public ApiResponse deleteTask(@PathVariable int index) {
        tasks.remove(index);
        return new ApiResponse("task deleted!");
    }

    @PutMapping("/status/{index}")
    public ApiResponse changeStauts(@PathVariable int index, @RequestBody Task  tas) {
        tasks.get(index).setStatus(tas.getStatus());
        return new ApiResponse("status updated!");
    }

    @GetMapping("/search")
    public ApiResponse search(@RequestBody Task  tas) {
        String title = tas.getTitle();
        for(int i = 0 ; i < tasks.size() ; i++){
            if( tasks.get(i).getTitle().matches(title)){
                return new ApiResponse("your task is  : " + tasks.get(i));
            }
        }
        return new ApiResponse("task not found.." + title);
    }


}
