package com.example.day2task;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class Day2TaskApplication {

    public static void main(String[] args) {
        SpringApplication.run(Day2TaskApplication.class, args);
    }

}
